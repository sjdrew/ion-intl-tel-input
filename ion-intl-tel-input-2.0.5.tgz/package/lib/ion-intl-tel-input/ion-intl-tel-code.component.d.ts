import { OnInit } from "@angular/core";
import { IonSearchbar, ModalController } from "@ionic/angular";
import { CountryI } from "../models/country.model";
import * as i0 from "@angular/core";
export declare class IonIntTelCodeComponent implements OnInit {
    private modalCtrl;
    country: CountryI;
    canSearch: boolean;
    closeButtonText: string;
    closeButtonSlot: string;
    countries: CountryI[];
    searchFailText: string;
    searchPlaceholder: string;
    shouldFocusSearchbar: boolean;
    title: string;
    dialCode: string;
    sbar: IonSearchbar;
    private allCountries;
    notFound: any;
    constructor(modalCtrl: ModalController);
    ngOnInit(): void;
    ionViewDidEnter(): void;
    search(ev: any): void;
    itemTapped(c: any): void;
    closeModal(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IonIntTelCodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IonIntTelCodeComponent, "ion-intl-tel-code", never, { "country": { "alias": "country"; "required": false; }; "canSearch": { "alias": "canSearch"; "required": false; }; "closeButtonText": { "alias": "closeButtonText"; "required": false; }; "closeButtonSlot": { "alias": "closeButtonSlot"; "required": false; }; "countries": { "alias": "countries"; "required": false; }; "searchFailText": { "alias": "searchFailText"; "required": false; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; }; "shouldFocusSearchbar": { "alias": "shouldFocusSearchbar"; "required": false; }; "title": { "alias": "title"; "required": false; }; "dialCode": { "alias": "dialCode"; "required": false; }; }, {}, never, never, false, never>;
}
